<?php

include 'database.php';
$pdo = Database::connect();
$sql = 'SELECT * FROM `ed_docs_requests_tpl` WHERE `project_id` = '.$_GET['project_id'].'';
foreach ($pdo->query($sql) as $row) {

		$projectName = $row['title'];
		$project_id = $row['project_id'];
		$postFields = unserialize( $row['form_fields'] );

                   }

							if (!empty($_POST)) {

                 		$form_title = $_POST['form_title'];
								 			$project_id = $_POST['project_id'];
                      $fileUpload =  $_FILES['fileUpload'];
											$target_path = "upload/";
sleep(3);
											foreach ($_FILES['fileUpload']['name'] as $key=>$value) {
                        	$newName = time().'-'.$_FILES['fileUpload']['name'][$key];
											    $path = $target_path . $newName;
													$date = date('Y-m-d H:i:s');
													$size = $_FILES['fileUpload']['size'][$key];
												  // $name =	$_POST['name'][$key];
												  $name = $_FILES["fileUpload"]["name"][$key];
												  
												  move_uploaded_file($_FILES['fileUpload']['tmp_name'][$key], $path);

													$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
													$sql = "INSERT INTO project_files (file_name,description,file_size,created_at,project_id,uploaded_by) values(?,?,?,?,?,?)";
													$q = $pdo->prepare($sql);
												  $inserted =	$q->execute(array($newName,$name,$size,$date,$project_id,'50000'));
													Database::disconnect();
											  }
												if($inserted){
													$sMsg = "File Uploded Successfully";
												}else{
														$sMsg = "failed Please try again";
												}
              }
 ?>

<?php include 'layouts/header.php'; ?>
    <body>
<div class="header">
			
				<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Dynamic Forms</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">service-1</a></li>
		    <li><a href="#">service-2</a></li>
		    <li><a href="#">service-3</a></li>
          </ul>
        </li>
        <li><a href="#">Hotel Management</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
		</div>
		
		<div class="maindiv">
			<div class="container">
			

        <!-- <form  method="POST" class="" enctype="multipart/form-data"> -->

			<?php
				$chkbox = $postFields['chk'];

				$BX_NAME=$postFields['BX_NAME'];
			?>
			<fieldset class="row">
					
				<legend>Hotel managment System</legend>
					<?php if(isset($sMsg)){echo "<div class='alert alert-success'><strong>Success! </strong> ".$sMsg.".</div>";}?>
					<div class="col-sm-6">
						<div class="form-group">
							<label class="control-label">Hotel Name *</label>
							<input name="form_title" class="form-control" value='<?php echo $projectName; ?>' type="text" required="required"/>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group ">
							<label class="control-label">Hotel Id</label>
							<input name="project_id" class="form-control"  value='<?php echo $project_id; ?>' type="text" required="required"/>
						</div>
					</div>
            </fieldset>
            
			<fieldset class="row">
				<div class="col-sm-6">
                <legend>Upload your documents here</legend>
				<div class="table-responsive">
                <table id="dataTable" class="table form" border="1" width="90%">
					<tbody>
					<?php foreach($BX_NAME as $a => $b){ ?>
						<tr>
							<p>
								<td><i class="fa fa-arrows-alt"></i></td>
								<td>
									&nbsp;
								</td>
								<td>
									<input type="text" readonly="readonly" name="name[]" value="<?php echo $BX_NAME[$a]; ?>">
								</td>
								<td>
                            		<label for="BX_gender">File</label>
                            		<input type="file" class="fileUpload" name="fileUpload[]" datatragetclass="Showuploded<?php echo $a; ?>" multiple/>
                            		<label for="BX_gender">File 2</label>
                            		<form action="upload.php" method="post">
                            		<input type="file" name="multiple_files" class="multiple_files" 
                            		multiple />

                            		</form>
                            		<span id="error_multiple_files"></span>
                         		</td>
                         		
							</p>
						</tr>
						<tr><td class="Showuploded<?php echo $a; ?>" colspan="4"></td></tr>
					<?php } ?>
					</tbody>
                </table>
				</div>
				</div>
				<div class="col-sm-6">
					<div class="clear"></div>
					<p>
						<input class="submit btn btn-primary" type="submit" name="submit" value="Submit"/>
				    </p>
				</div>
            </fieldset>


		

			<div class="clear"></div>
       <!--  </form> -->
				
				
		</div>
		
		</div>
    </body>
	<!-- Start of StatCounter Code for Default Guide -->
	<script type="text/javascript">
		$('.fileUpload').change(function () {
		  var targetClass = "." + $(this).attr('datatragetclass');
		  $(targetClass).empty();

			// alert(targetClass);
			// $('<tr><td class="Showuploded" colspan="4"></td></tr>').insertAfter($(this).closest('tr'));
    for (var i=0, len = this.files.length; i < len; i++) {
        (function (j, self) {
            var reader = new FileReader()
            reader.onload = function (e) {

                $(targetClass).append('<li><img width="20px" src="' + e.target.result + '">' + self.files[j].name + '</li>')
                
            }
            reader.readAsDataURL(self.files[j])
        })(i, this);
    }
});



		$(function(){

			$('.multiple_files').change(function(e){
				e.preventDefault();
				 var form_data = new FormData();
				 for(var i=0; i < this.files.length; i++){
				 form_data.append("file[]", this.files[i]);
				 }
				console.log(form_data);

				 $.ajax({
				    url:"upload.php",
				    method:"POST",
				    data: form_data,
				    contentType: false,
				    cache: false,
				    processData: false,
				    beforeSend:function(){
				     $('#error_multiple_files').html('<br /><label class="text-primary">Uploading...</label>');
				    },   
				    success:function(data)
				    {
				     $('#error_multiple_files').html('<br /><label class="text-success">Uploaded</label>');
				
				    }
				   });




			})


		})










	</script>
<?php include 'layouts/footer.php'; ?>