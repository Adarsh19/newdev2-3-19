-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2019 at 10:06 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projectmanagment`
--

-- --------------------------------------------------------

--
-- Table structure for table `ed_docs_requests_tpl`
--

CREATE TABLE IF NOT EXISTS `ed_docs_requests_tpl` (
`id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `form_fields` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `deleted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ed_docs_requests_tpl`
--

INSERT INTO `ed_docs_requests_tpl` (`id`, `title`, `form_fields`, `project_id`, `status`, `deleted`) VALUES
(2, 'trs', 'a:4:{s:10:"form_title";s:3:"trs";s:10:"project_id";s:4:"1234";s:3:"chk";a:1:{i:0;s:2:"on";}s:7:"BX_NAME";a:1:{i:0;s:5:"fname";}}', 1234, NULL, '2019-02-15 10:19:18');

-- --------------------------------------------------------

--
-- Table structure for table `project_files`
--

CREATE TABLE IF NOT EXISTS `project_files` (
`id` int(11) NOT NULL,
  `file_name` text,
  `description` mediumtext,
  `file_size` double DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `project_id` int(11) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `project_files`
--

INSERT INTO `project_files` (`id`, `file_name`, `description`, `file_size`, `created_at`, `project_id`, `uploaded_by`, `deleted`) VALUES
(1, '1550206266-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 05:51:06', 1234, 50000, NULL),
(2, '1550216404-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 08:40:04', 1234, 50000, NULL),
(3, '1550216447-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 08:40:47', 1234, 50000, NULL),
(4, '1550216469-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 08:41:09', 1234, 50000, NULL),
(5, '1550217770-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:02:50', 1234, 50000, NULL),
(6, '1550220576-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:49:36', 1234, 50000, NULL),
(7, '1550220591-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:49:51', 1234, 50000, NULL),
(8, '1550220619-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:50:19', 1234, 50000, NULL),
(9, '1550220671-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:51:11', 1234, 50000, NULL),
(10, '1550220687-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:51:27', 1234, 50000, NULL),
(11, '1550220717-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:51:57', 1234, 50000, NULL),
(12, '1550220757-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:52:37', 1234, 50000, NULL),
(13, '1550220778-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:52:58', 1234, 50000, NULL),
(14, '1550220820-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:53:40', 1234, 50000, NULL),
(15, '1550220826-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:53:46', 1234, 50000, NULL),
(16, '1550220865-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:54:25', 1234, 50000, NULL),
(17, '1550220870-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:54:30', 1234, 50000, NULL),
(18, '1550220960-Chrysanthemum.jpg', 'fname', 879394, '2019-02-15 09:56:00', 1234, 50000, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ed_docs_requests_tpl`
--
ALTER TABLE `ed_docs_requests_tpl`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_files`
--
ALTER TABLE `project_files`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ed_docs_requests_tpl`
--
ALTER TABLE `ed_docs_requests_tpl`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `project_files`
--
ALTER TABLE `project_files`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
