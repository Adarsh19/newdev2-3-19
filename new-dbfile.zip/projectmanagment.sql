-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2019 at 05:42 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectmanagment`
--

-- --------------------------------------------------------

--
-- Table structure for table `ed_docs_requests_tpl`
--

CREATE TABLE `ed_docs_requests_tpl` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `form_fields` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `deleted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ed_docs_requests_tpl`
--

INSERT INTO `ed_docs_requests_tpl` (`id`, `title`, `form_fields`, `project_id`, `status`, `deleted`) VALUES
(6, 'title', 'a:4:{s:10:\"form_title\";s:5:\"title\";s:10:\"project_id\";s:5:\"title\";s:3:\"chk\";a:3:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";}s:7:\"BX_NAME\";a:3:{i:0;s:5:\"sdfsd\";i:1;s:7:\"hdfgdfg\";i:2;s:8:\"vcbcbcvb\";}}', NULL, NULL, '2019-02-07 11:18:39'),
(7, 'priject title', 'a:4:{s:10:\"form_title\";s:13:\"priject title\";s:10:\"project_id\";s:1:\"2\";s:3:\"chk\";a:2:{i:0;s:2:\"on\";i:1;s:2:\"on\";}s:7:\"BX_NAME\";a:2:{i:0;s:7:\"Field 1\";i:1;s:7:\"Field 2\";}}', 2, NULL, '2019-02-07 11:24:26'),
(8, 'title', 'a:4:{s:10:\"form_title\";s:5:\"title\";s:10:\"project_id\";s:5:\"title\";s:3:\"chk\";a:3:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";}s:7:\"BX_NAME\";a:3:{i:0;s:9:\"vcbvcbcvb\";i:1;s:12:\"vcbvcbcvbcvb\";i:2;s:17:\"xcvxcvxcvxcvxcvxc\";}}', 5, NULL, '2019-02-08 11:27:15'),
(9, 'asdasd', 'a:4:{s:10:\"form_title\";s:6:\"asdasd\";s:10:\"project_id\";s:2:\"12\";s:3:\"chk\";a:3:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";}s:7:\"BX_NAME\";a:3:{i:0;s:8:\"Passport\";i:1;s:13:\"Election card\";i:2;s:9:\"Pass Book\";}}', 12, NULL, '2019-02-09 21:45:31'),
(10, 'Test Project', 'a:4:{s:10:\"form_title\";s:12:\"Test Project\";s:10:\"project_id\";s:2:\"54\";s:3:\"chk\";a:2:{i:0;s:2:\"on\";i:1;s:2:\"on\";}s:7:\"BX_NAME\";a:2:{i:0;s:5:\"Adhar\";i:1;s:8:\"Passbook\";}}', 54, NULL, '2019-02-10 14:30:05'),
(11, 'asdasd', 'a:4:{s:10:\"form_title\";s:6:\"asdasd\";s:10:\"project_id\";s:2:\"23\";s:3:\"chk\";a:3:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";}s:7:\"BX_NAME\";a:3:{i:0;s:3:\"tet\";i:1;s:4:\"sdad\";i:2;s:6:\"sadasd\";}}', 23, NULL, '2019-02-10 14:43:15'),
(12, 'locker', 'a:4:{s:10:\"form_title\";s:6:\"locker\";s:10:\"project_id\";s:3:\"123\";s:3:\"chk\";a:2:{i:0;s:2:\"on\";i:1;s:2:\"on\";}s:7:\"BX_NAME\";a:2:{i:0;s:5:\"tohhh\";i:1;s:5:\"Adhar\";}}', 123, NULL, '2019-02-10 16:24:29'),
(13, 'Send money', 'a:4:{s:10:\"form_title\";s:10:\"Send money\";s:10:\"project_id\";s:3:\"564\";s:3:\"chk\";a:3:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";}s:7:\"BX_NAME\";a:3:{i:0;s:37:\"Payslip from 10-20-2019 to 15-03-2019\";i:1;s:8:\"Passport\";i:2;s:15:\"Driving Licence\";}}', 564, NULL, '2019-02-10 16:28:01'),
(14, 'sdfsd', 'a:4:{s:10:\"form_title\";s:5:\"sdfsd\";s:10:\"project_id\";s:3:\"854\";s:3:\"chk\";a:4:{i:0;s:2:\"on\";i:1;s:2:\"on\";i:2;s:2:\"on\";i:3;s:2:\"on\";}s:7:\"BX_NAME\";a:4:{i:0;s:17:\"Group Certificate\";i:1;s:15:\"Driving Licence\";i:2;s:7:\"Payslip\";i:3;s:8:\"Passport\";}}', 854, NULL, '2019-02-10 16:32:42');

-- --------------------------------------------------------

--
-- Table structure for table `project_files`
--

CREATE TABLE `project_files` (
  `id` int(11) NOT NULL,
  `file_name` text,
  `description` mediumtext,
  `file_size` double DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `project_id` int(11) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `deleted` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project_files`
--

INSERT INTO `project_files` (`id`, `file_name`, `description`, `file_size`, `created_at`, `project_id`, `uploaded_by`, `deleted`) VALUES
(1, '1549789238-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', '', 98486, '2019-02-10 10:00:38', 54, 0, NULL),
(2, '1549789238-20%sale.png', '', 856770, '2019-02-10 10:00:38', 54, 0, NULL),
(3, '1549792145-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Passport', 98486, '2019-02-10 10:49:05', 12, 50000, NULL),
(4, '1549792145-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Election card', 98486, '2019-02-10 10:49:05', 12, 50000, NULL),
(5, '1549792145-18c9Wg2.jpg', 'Pass Book', 45610, '2019-02-10 10:49:05', 12, 50000, NULL),
(6, '1549792245-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Passport', 98486, '2019-02-10 10:50:45', 12, 50000, NULL),
(7, '1549792245-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Election card', 98486, '2019-02-10 10:50:45', 12, 50000, NULL),
(8, '1549792245-18c9Wg2.jpg', 'Pass Book', 45610, '2019-02-10 10:50:45', 12, 50000, NULL),
(9, '1549792314-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Passport', 98486, '2019-02-10 10:51:54', 12, 50000, NULL),
(10, '1549792314-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Election card', 98486, '2019-02-10 10:51:54', 12, 50000, NULL),
(11, '1549792314-18c9Wg2.jpg', 'Pass Book', 45610, '2019-02-10 10:51:54', 12, 50000, NULL),
(12, '1549792349-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Passport', 98486, '2019-02-10 10:52:29', 12, 50000, NULL),
(13, '1549792349-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Election card', 98486, '2019-02-10 10:52:29', 12, 50000, NULL),
(14, '1549792349-18c9Wg2.jpg', 'Pass Book', 45610, '2019-02-10 10:52:29', 12, 50000, NULL),
(15, '1549792383-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Passport', 98486, '2019-02-10 10:53:03', 12, 50000, NULL),
(16, '1549792383-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Election card', 98486, '2019-02-10 10:53:03', 12, 50000, NULL),
(17, '1549792383-18c9Wg2.jpg', 'Pass Book', 45610, '2019-02-10 10:53:03', 12, 50000, NULL),
(18, '1549796114-', 'Adhar', 0, '2019-02-10 11:55:14', 123, 50000, NULL),
(19, '1549796114-', 'tohhh', 0, '2019-02-10 11:55:14', 123, 50000, NULL),
(20, '1549796607-3d-render-of-spotlights-on-a-grunge-brick-wall_1048-6284.jpg', 'Group Certificate', 98486, '2019-02-10 12:03:27', 854, 50000, NULL),
(21, '1549796607-18c9Wg2.jpg', 'Driving Licence', 45610, '2019-02-10 12:03:27', 854, 50000, NULL),
(22, '1549796607-20%sale.png', 'Payslip', 856770, '2019-02-10 12:03:27', 854, 50000, NULL),
(23, '1549796607-elon.jpeg', 'Passport', 177292, '2019-02-10 12:03:27', 854, 50000, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ed_docs_requests_tpl`
--
ALTER TABLE `ed_docs_requests_tpl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_files`
--
ALTER TABLE `project_files`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ed_docs_requests_tpl`
--
ALTER TABLE `ed_docs_requests_tpl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `project_files`
--
ALTER TABLE `project_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
