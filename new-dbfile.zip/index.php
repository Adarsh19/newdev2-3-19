<?php include 'layouts/header.php'; ?>
    <body>
		<div class="header">
				<nav class="navbar navbar-inverse">
				  <div class="container-fluid">
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>                        
					  </button>
					  <a class="navbar-brand" href="#">Dynamic Forms</a>
					</div>
					<div class="collapse navbar-collapse" id="myNavbar">
					  <ul class="nav navbar-nav">
						<li class="active"><a href="#">Home</a></li>
						<li class="dropdown">
						  <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services <span class="caret"></span></a>
						  <ul class="dropdown-menu">
							<li><a href="#">Service-1</a></li>
							<li><a href="#">Service-2</a></li>
							<li><a href="#">Service-3</a></li>
						  </ul>
						</li>
						<li><a href="#">Process Management</a></li>
						<li><a href="#">About</a></li>
						<li><a href="#">Contact Us</a></li>
					  </ul>
					  <ul class="nav navbar-nav navbar-right">
						<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
						<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
					  </ul>
					</div>
				  </div>
				</nav>
		</div>
		
		<div class="maindiv">
			<div class="container">
				<form action='createForm.php' class=""  method='POST' enctype='multipart/form-data'>

				<h2>Project managment System</h2>
				<fieldset class="row">
					<legend>Add new Form</legend>
					<div class="col-sm-6">
					<div class="form-group ">
						<label class="control-label">Project Name *
						</label>
						<input name="form_title" class="form-control" value='' type="text" required="required"/>
					</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label class="control-label">Project Id	(e.g: 1122)</label>
							<input name="project_id" class="form-control" value='' type="text" required="required"/>
						</div>					
					</div>
				   
					<div class="clear"></div>
				</fieldset>
				<fieldset class="row">
					<legend>Details</legend>
					<div class="col-sm-6">
					<p>
						<input type="button" class="btn btn-primary" style="color: #fff;" value="Add Fields" onClick="addRow('dataTable')" />
						<input type="button" class="btn btn-warning" style="color: #fff;" value="Remove Fields" onClick="deleteRow('dataTable')"  />
						<p>(All acions apply only to entries with check marked check boxes only.)</p>
					</p>
				   <table id="dataTable" class="form" border="1">
					  <tbody>
						<tr>
						  <p>
							<td><i class="fa fa-arrows-alt"></i></td>
							<td><input type="checkbox" required="required" name="chk[]" checked="checked" /></td>
							<td>
								<div class="form-group ">
								<label class="control-label">Name</label>
								<input class="form-control" type="text" required="required" name="BX_NAME[]">
							</div>
							 </td>
							 <td>
								<div class="form-group ">
								<label class="control-label " for="BX_file">File</label>
								<input  type="file" class="small"  name="fileUpload[]">
							</div>
							 </td>

								</p>
						</tr>
						</tbody>
					</table>
					</div>
					<div class="col-sm-6">
						<h4>Further Information</h4>
						<p>The identification details are required during journey. One of the passenger booked on the ticket should have any of the identity cards ( Passport / PAN Card / Driving License / Photo ID card issued by Central / State Govt / Student Identity Card with photograph) during the journey in original. </p>
						<h4>Terms and Mailing</h4>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>*  I accept the <a href="#">Terms and Conditions</a></label>
						</p>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>I want to receive personalized offers by your Service</label>
						</p>
						<p><input class="submit btn btn-primary" type="submit" value="Confirm &raquo;" /></p>
					</div>
					<div class="clear"></div>
					<!--<div class="col-sm-6">
						<h4>Terms and Mailing</h4>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>*  I accept the <a href="#">Terms and Conditions</a></label>
						</p>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>I want to receive personalized offers by your Service</label>
						</p>
					</div>
					
					<div class="col-sm-6">
						<h4>Terms and Mailing</h4>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>*  I accept the <a href="#">Terms and Conditions</a></label>
						</p>
						<p class="agreement">
							<input type="checkbox" value=""/>
							<label>I want to receive personalized offers by your Service</label>
						</p>
						<p><input class="submit btn btn-primary" type="submit" value="Confirm &raquo;" /></p>
					</div>-->
				</fieldset>
				
				
				
				

				<div class="clear"></div>
				</form>
			</div>
		</div>
    
    <!-- Start of StatCounter Code for Default Guide -->
<?php include 'layouts/footer.php'; ?>



                